from pathlib import Path
import subprocess,json,time,hashlib
root=Path.cwd();audit=root/'build/ai-audit';cp=str(audit/'test-classes')+':'+(audit/'candidate2-classpath.txt').read_text();props='-Dlog4j.configuration=file:'+str(root/'experiments/commander-ai/adapter/soak/log4j.properties')
for batch in range(3):
 out=audit/f'fixed{batch}';out.mkdir(exist_ok=False)
 pods=[[0,1,2,3],[4,5,6,7],[8,9,0,6]]
 for i,pod in enumerate(pods):
  indexes=[str((d+batch*3)%10) for d in pod];seed=20261024+batch*100+i
  with (out/f'pod-{i}.log').open('w') as log:
   start=time.time();result=subprocess.run(['timeout','--signal=TERM','--kill-after=5','300','java',props,'-Xmx1400m','-ea','-cp',cp,'mage.player.ai.FourthSeatSoak',str(audit/'decks'),str(seed),'120',*indexes],stdout=log,stderr=subprocess.STDOUT)
  with (out/'summary.log').open('a') as summary:summary.write(f'POD {i} exit={result.returncode} decks={" ".join(indexes)}\n')
  print(f'batch={batch} pod={i} exit={result.returncode} seconds={time.time()-start:.1f}',flush=True)
 subprocess.run(['python3',str(root/'experiments/commander-ai/adapter/soak/summarize.py'),str(out)],stdout=(out/'report.log').open('w'))
print('FIXED COMPLETE',flush=True)
